"""
Global seeding helper. Call seed_everything() once, near the start of
your entry-point script (see main.py), before building datasets/models.
"""

import random

import numpy as np
import torch


def seed_everything(seed=42):

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
